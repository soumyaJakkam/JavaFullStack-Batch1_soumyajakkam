package com.verizon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.verizon.model.Product;
import com.verizon.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;

	@PostMapping("/product")
	public ResponseEntity<String> addProductDetails(@RequestBody Product product) {
		productService.addProduct(product);
		return new ResponseEntity<>("Product added successfully!", HttpStatus.CREATED);
	}

	@GetMapping("/product")
	public ResponseEntity<List<Product>> getAllProducts() {
		List<Product> products = productService.getAllProducts();
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable("id") Integer id) {
		Product product = productService.getProductById(id); // Throws ProductNotFoundException if not found
		return new ResponseEntity<>(product, HttpStatus.OK);
	}

	@GetMapping("/product/{low}/{high}")
	public ResponseEntity<List<Product>> getAllProductsBetweenPrice(@PathVariable("low") Integer low, @PathVariable("high") Integer high) {
		List<Product> products = productService.getAllProductsBetweenPrice(low, high);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@PutMapping("/product/{id}")
	public ResponseEntity<Void> updateProductDetails(@PathVariable("id") Integer id, @RequestBody Product product) {
		productService.updateProduct(id, product); // Throws ProductNotFoundException if not found
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping("/product/{id}")
	public ResponseEntity<Void> deleteProductDetails(@PathVariable("id") Integer id) {
		productService.deleteProduct(id); // Throws ProductNotFoundException if not found
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
