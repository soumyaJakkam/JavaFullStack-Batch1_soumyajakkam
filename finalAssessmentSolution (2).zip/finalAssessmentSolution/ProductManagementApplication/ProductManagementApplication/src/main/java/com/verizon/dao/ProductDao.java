package com.verizon.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.verizon.model.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {
	// Custom query to find products between low and high price
	List<Product> findByPriceBetween(Integer low, Integer high);
}
