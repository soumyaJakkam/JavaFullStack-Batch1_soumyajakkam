package com.verizon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verizon.dao.ProductDao;
import com.verizon.model.Product;
import com.verizon.exception.ProductNotFoundException;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductService {

	@Autowired
	ProductDao productDao;

	// 1. Add Product
	public void addProduct(Product product) {
		productDao.save(product);
	}

	// 2. Get all products
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	// 3. Get product by ID, throw ProductNotFoundException if not found
	public Product getProductById(Integer id) throws ProductNotFoundException {
		return productDao.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("Product with ID " + id + " not found"));
	}

	// 4. Get products between price range
	public List<Product> getAllProductsBetweenPrice(Integer low, Integer high) {
		return productDao.findByPriceBetween(low, high);
	}

	// 5. Update Product by ID
	public void updateProduct(Integer id, Product product) throws ProductNotFoundException {
		Product existingProduct = productDao.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("Product with ID " + id + " not found"));

		existingProduct.setPname(product.getPname());
		existingProduct.setPrice(product.getPrice());
		// Update other fields if needed

		productDao.save(existingProduct);
	}

	// 6. Delete Product by ID
	public void deleteProduct(Integer id) throws ProductNotFoundException {
		Product product = productDao.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("Product with ID " + id + " not found"));
		productDao.delete(product);
	}
}
